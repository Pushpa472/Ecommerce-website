
function add_to_cart(pid, pname, price, pquantity, pphoto)
{

    let cart = localStorage.getItem("cart");
    if (cart == null)
    {
        //no cart yet  
        let products = [];
        let product = {productId: pid, productName: pname, productQuantity: 1, productPrice: price, productPhoto: pphoto}
        products.push(product);
        localStorage.setItem("cart", JSON.stringify(products));
//        console.log("Product is added for the first time")
        showToast("Item is added to cart")
    } else
    {
        //cart is already present
        let pcart = JSON.parse(cart);

        let oldProduct = pcart.find((item) => item.productId == pid)
        console.log(oldProduct)
        if (oldProduct)
        {
            //we have to increase the quantity
            oldProduct.productQuantity = oldProduct.productQuantity + 1
            pcart.map((item) => {

                if (item.productId === oldProduct.productId)
                {
                    item.productQuantity = oldProduct.productQuantity;
                }

            })
            localStorage.setItem("cart", JSON.stringify(pcart));
            console.log("Product quantity is increased")
            showToast(oldProduct.productName + " quantity is increased , Quantity = " + oldProduct.productQuantity)

        } else
        {
            //we have add the product
            let product = {productId: pid, productName: pname, productQuantity: 1, productPrice: price, productPhoto: pphoto}
            pcart.push(product)
            localStorage.setItem("cart", JSON.stringify(pcart));
            console.log("Product is added")
            showToast("Product is added to cart")
        }


    }


    updateCart();

}

//update cart:

function updateCart()
{
    let cartString = localStorage.getItem("cart");
    let cart = JSON.parse(cartString);
    if (cart == null || cart.length == 0)
    {
        console.log("Cart is empty !!")
        $(".cart-items").html("( 0 )");
        $(".cart-body").html("<h3>Cart does not have any items </h3>");
        $(".checkout-btn").attr('disabled', true)
    } else
    {


        //there is some in cart to show
        console.log(cart)
        $(".cart-items").html(`( ${cart.length} )`);
        let table = `
            <table class='table'>
            <thead class='thread-light'>
                <tr>
                <th>Image</th>
                <th>Item Name </th>
                <th>Price </th>
                <th>Quantity </th>
                <th>Total Price </th>
                <th>Action</th>
                
        
                </tr>
        
            </thead>

        


            `;

        let totalPrice = 0;
        cart.map((item) => {


            table += `
                    <tr>
                        <td><img src="img/products/${item.productPhoto}" style="width: 60px; height: 60px; width: auto;"></td>
                        <td> ${item.productName} </td>
                        <td> ${item.productPrice} </td>
                        <td> ${item.productQuantity} </td>
                        <td> ${item.productQuantity * item.productPrice} </td>
                        <td> <button onclick='deleteItemFromCart(${item.productId})' class='btn btn-danger btn-sm'>Remove</button> </td>    
                     </tr>
                 `

            totalPrice += item.productPrice * item.productQuantity;

        })




        table = table + `
            <tr><td colspan='5' class='text-right font-weight-bold m-5'> Total Price : ${totalPrice} </td></tr>
         </table>`
        $(".cart-body").html(table);
        $(".checkout-btn").attr('disabled', false)
        console.log("removed")

    }

}


//delete item 
function deleteItemFromCart(pid)
{
    let cart = JSON.parse(localStorage.getItem('cart'));

    let newcart = cart.filter((item) => item.productId != pid)

    localStorage.setItem('cart', JSON.stringify(newcart))

    updateCart();

    showToast("Item is removed from cart ")

}


$(document).ready(function () {

    updateCart()
})


function showToast(content) {
    $("#toast").addClass("display");
    $("#toast").html(content);
    setTimeout(() => {
        $("#toast").removeClass("display");
    }, 2000);
}


function goToCheckout() {

    window.location = "checkout.jsp"

}


//contact us limit msg
function validateForm() {
        // Get the message content
        var message = document.getElementById("message").value;

        // Check if the message exceeds 100 words
        var wordCount = message.trim().split(/\s+/).length;
        if (wordCount > 100) {
            alert("You cannot write more than 100 words. Please shorten your message.");
        } else {
            // If the message is within the limit, you can proceed with submitting the form
            // You may want to add additional validation or use AJAX to submit the form data
            alert("Form submitted successfully!");
        }
    }


 //password
  function checkPasswordFormat(password) {
        var passwordRegex = /^(?=(?:[^a-z]*[a-z]){2})(?=(?:[^A-Z]*[A-Z]){2})(?=(?:[^\d]*\d){2})[a-zA-Z\d]{6,}$/;

        var isPasswordValid = passwordRegex.test(password);

        var passwordHelp = document.getElementById("passwordHelp");

        if (isPasswordValid) {
            passwordHelp.innerHTML = "Password format: Valid";
            passwordHelp.style.color = "green";
        } else {
            passwordHelp.innerHTML = "Password must contain numeric characters.";
            passwordHelp.style.color = "red";
        }
    }

    
//

    function completePayment(paymentMode) {
    var form = document.createElement('form');
    form.method = 'post';
    form.action = 'OrderOperationServlet'; // Change this to the correct URL of your servlet

    var paymentInput = document.createElement('input');
    paymentInput.type = 'hidden';
    paymentInput.name = 'paymentMode';
    paymentInput.value = paymentMode;
    form.appendChild(paymentInput);

    document.body.appendChild(form);
    form.submit();

    // Clear cart items from local storage
    localStorage.removeItem("cart");

    // Display success message
    showToast("Order Placed Successfully!");
}








