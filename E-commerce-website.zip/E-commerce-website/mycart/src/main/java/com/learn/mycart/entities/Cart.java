package com.learn.mycart.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Cart {
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	   private int cartId;
       private String pPhoto;
       private int pId;
       private String pName;
       private int userId;
       private String categoryTitle;
       private int pQuantity;
       private int pPrice;
       
	public Cart(int cartId, String pPhoto, int pId, String pName, int userId, String categoryTitle, int pQuantity,
			int pPrice) {
		super();
		this.cartId = cartId;
		this.pPhoto = pPhoto;
		this.pId = pId;
		this.pName = pName;
		this.userId = userId;
		this.categoryTitle = categoryTitle;
		this.pQuantity = pQuantity;
		this.pPrice = pPrice;
	}

	public Cart() {
		super();
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public String getpPhoto() {
		return pPhoto;
	}

	public void setpPhoto(String pPhoto) {
		this.pPhoto = pPhoto;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getCategoryTitle() {
		return categoryTitle;
	}

	public void setCategoryTitle(String categoryTitle) {
		this.categoryTitle = categoryTitle;
	}

	public int getpQuantity() {
		return pQuantity;
	}

	public void setpQuantity(int pQuantity) {
		this.pQuantity = pQuantity;
	}

	public int getpPrice() {
		return pPrice;
	}

	public void setpPrice(int pPrice) {
		this.pPrice = pPrice;
	}

	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", pPhoto=" + pPhoto + ", pId=" + pId + ", pName=" + pName + ", userId="
				+ userId + ", categoryTitle=" + categoryTitle + ", pQuantity=" + pQuantity + ", pPrice=" + pPrice + "]";
	}
       
		
}
