package com.learn.mycart.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.learn.mycart.dao.CartDao;

public class CartServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
                // Get the parameters from the request
                int productId = Integer.parseInt(request.getParameter("productId"));
                String productName = request.getParameter("productName");
                int productPrice = Integer.parseInt(request.getParameter("productPrice"));
                int productQuantity = Integer.parseInt(request.getParameter("productQuantity"));
                String productPhoto = request.getParameter("productPhoto");

                // Add the product to the cart
                CartDao cartDao = new CartDao();
                cartDao.addToCart(productId, productName, productPrice, productQuantity, productPhoto);

                // Send a success response
                response.setStatus(HttpServletResponse.SC_OK);
            }

            protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                // Display the cart page
                request.getRequestDispatcher("cart.jsp").forward(request, response);
            }
        }
    
