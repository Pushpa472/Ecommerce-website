package com.learn.mycart.dao;

import org.hibernate.SessionFactory;
import com.learn.mycart.entities.Order;
import org.hibernate.Transaction;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.query.Query;

public class OrderDao {
	 private final SessionFactory sessionFactory;

	    public OrderDao(SessionFactory sessionFactory) {
	        this.sessionFactory = sessionFactory;
	    }

	    public int insertOrder(Order order) {
	        Transaction transaction = null;
	        int id = 0;
	        try (Session session = sessionFactory.openSession()) {
	            transaction = session.beginTransaction();
	            id = (int) session.save(order);
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }
	        return id;
	    }

	    public List<Order> getAllOrderByUserId(int userId) {
	        try (Session session = sessionFactory.openSession()) {
	            Query<Order> query = session.createQuery("FROM Order WHERE userId = :userId", Order.class);
	            query.setParameter("userId", userId);
	            return query.list();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return null;
	    }

	    public List<Order> getAllOrderedProduct(int orderId) {
	        try (Session session = sessionFactory.openSession()) {
	            Query<Order> query = session.createQuery("FROM Order WHERE orderId = :orderId", Order.class);
	            query.setParameter("orderId", orderId);
	            return query.list();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return null;
	    }

	    public Order getOrderById(int id) {
	        try (Session session = sessionFactory.openSession()) {
	            return session.get(Order.class, id);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return null;
	    }

	    public List<Order> getAllOrder() {
	        try (Session session = sessionFactory.openSession()) {
	            return session.createQuery("FROM Order", Order.class).list();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return null;
	    }

	    public void updateOrderStatus(int orderId, String status) {
	        try (Session session = sessionFactory.openSession()) {
	            Transaction transaction = session.beginTransaction();
	            Order order = session.get(Order.class, orderId);
	            if (order != null) {
	                order.setStatus(status);
	            }
	            transaction.commit();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
}
