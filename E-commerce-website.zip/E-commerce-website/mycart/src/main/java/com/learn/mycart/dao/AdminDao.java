package com.learn.mycart.dao;

import com.learn.mycart.entities.Admin;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.learn.mycart.entities.User;

public class AdminDao {
	
	 private SessionFactory factory;

	    public AdminDao(SessionFactory factory) {
	        this.factory = factory;
	    }
	    
	public boolean isAdmin(String email, String password) {
        boolean isAdmin = false;

        try {
            String query = "from User where userEmail =: e and userPassword=: p and userType = 'admin'";
            Session session = this.factory.openSession();
            Query q = session.createQuery(query);
            q.setParameter("e", email);
            q.setParameter("p", password);
            User user = (User) q.uniqueResult();
            session.close();

            if (user != null) {
                isAdmin = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return isAdmin;
    }
}
