package com.learn.mycart.helper;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FactoryProvider {
   
	private static SessionFactory factory;
	private static final Object lock = new Object();

	public static SessionFactory getFactory() {
	    if (factory == null) {
	        synchronized (lock) {
	            if (factory == null) {
	                try {
	                    factory = new Configuration()
	                            .configure("hibernate.cfg.xml")
	                            .buildSessionFactory();
	                } catch (Throwable ex) {
	                    System.err.println("Initial SessionFactory creation failed." + ex);
	                    throw new ExceptionInInitializerError(ex);
	                }
	            }
	        }
	    }
	    return factory;
	}

}
