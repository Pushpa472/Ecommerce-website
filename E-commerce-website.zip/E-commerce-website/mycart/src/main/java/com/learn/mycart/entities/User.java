package com.learn.mycart.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(length = 10, name = "CustomerId")
    private int userId;
    @Column(length =100 , name = "CustomerName")
    private String userName;
    @Column(length = 100, name = "CustomerEmail")
    private String userEmail;
    @Column(length = 100, name = "CustomerPassword")
    private String userPassword;
    @Column(length = 12, name = "CustomerContact")
    private String userContact;
    @Column(length = 1500, name = "CustomerPic")
    private String userPic;
    @Column(length =1500 , name = "CustomerAddress")
    private String userAddress;
    
    @Column(name="CustomerType")
    private String userType;

    public User(int userId, String userName, String userEmail, String userPassword, String userContact, String userPic, String userAddress,String userType) {
        this.userId = userId;
        this.userName = userName;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
        this.userContact = userContact;
        this.userPic = userPic;
        this.userAddress = userAddress;
        this.userType=userType;
    }

    public User(String userName, String userEmail, String userPassword, String userContact, String userPic, String userAddress,String userType) {
        this.userName = userName;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
        this.userContact = userContact;
        this.userPic = userPic;
        this.userAddress = userAddress;
        this.userType=userType;
    }

    public User() {
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserContact() {
        return userContact;
    }

    public void setUserContact(String userContact) {
        this.userContact = userContact;
    }

    public String getUserPic() {
        return userPic;
    }

    public void setUserPic(String userPic) {
        this.userPic = userPic;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }
    
    

    @Override
    public String toString() {
        return "User{" + "userId=" + userId + ", userName=" + userName + ", userEmail=" + userEmail + ", userPassword=" + userPassword + ", userContact=" + userContact+ ", userPic=" + userPic + ", userAddress=" + userAddress + '}';
    }
    
      
}
