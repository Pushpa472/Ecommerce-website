package com.learn.mycart.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Payment {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String cardHolderName;
    private String cardNumber;
    private String cvv;
    private String expiryDate;
    private int Totalprice;
    
	public Payment(int id, String cardHolderName, String cardNumber, String cvv, String expiryDate,
			int totalprice) {
		super();
		this.id = id;
		this.cardHolderName = cardHolderName;
		this.cardNumber = cardNumber;
		this.cvv = cvv;
		this.expiryDate = expiryDate;
		Totalprice = totalprice;
	}

	public Payment() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public int getTotalprice() {
		return Totalprice;
	}

	public void setTotalprice(int totalprice) {
		Totalprice = totalprice;
	}

	@Override
	public String toString() {
		return "Payment [id=" + id + ", cardHolderName=" + cardHolderName + ", cardNumber=" + cardNumber + ", cvv="
				+ cvv + ", expiryDate=" + expiryDate + ", Totalprice=" + Totalprice + "]";
	}
      
}
