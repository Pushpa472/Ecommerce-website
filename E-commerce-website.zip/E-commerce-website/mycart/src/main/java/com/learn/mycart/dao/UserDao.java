
package com.learn.mycart.dao;

import com.learn.mycart.entities.User;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class UserDao {
    private SessionFactory factory;
	private SessionFactory sessionFactory;

    public UserDao(SessionFactory factory) {
        this.factory = factory;
    }
    
    //get user by email and password
    public User getUserByEmailAndPassword(String email,String password)
    {
        User user=null;
        
        try {
            
            String query="from User where userEmail =: e and userPassword=: p";
            Session session = this.factory.openSession();
            Query q = session.createQuery(query);
            q.setParameter("e", email);
            q.setParameter("p",password);            
            user=(User) q.uniqueResult();         
            session.close();         
            
            
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }     
        
        
        
        
        return user;
    }
  //update user
    public void updateUser(User user) {
        Transaction transaction = null;
        try (
        	Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();

            // Use session.get to load the User object from the database based on the user's ID
            User existingUser = session.get(User.class, user.getUserId());

            if (existingUser != null) {
                // Update the fields of the existing user with the values from the input user
                existingUser.setUserName(user.getUserName());
                existingUser.setUserEmail(user.getUserEmail());
                existingUser.setUserContact(user.getUserContact());
                existingUser.setUserAddress(user.getUserAddress());
               

                // No need to explicitly save or update the object, as it is attached to the session
            }

            transaction.commit();// Commit the transaction if all operations succeed
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();// Rollback the transaction if any operation fails
            }
            e.printStackTrace();
        }
    }
    
    
 // Get a user's name by their ID
    public String getUserName(int userId) {
        User user = getUserById(userId);
        return user != null ? user.getUserName() : null;
    }

    // Get a user's contact by their ID
    public String getUserContact(int userId) {
        User user = getUserById(userId);
        return user != null ? user.getUserContact() : null;
    }

    // Get a user's address by their ID
    public String getUserAddress(int userId) {
        User user = getUserById(userId);
        return user != null ? user.getUserAddress() : null;
    }

    // Get a user by their ID
    public User getUserById(int userId) {
        User user = null;
        try (Session session = factory.openSession()) {
            Transaction tx = session.beginTransaction();
            user = session.get(User.class, userId);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }
    
    
    public List<User> getAllUsers() {
        try (Session session = sessionFactory.openSession()) {
            Criteria criteria = session.createCriteria(User.class);
            return criteria.list();
        }
    }
}




