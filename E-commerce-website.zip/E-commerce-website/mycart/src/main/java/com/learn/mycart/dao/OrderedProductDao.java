package com.learn.mycart.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.learn.mycart.entities.OrderedProduct;
import java.util.ArrayList;
import java.util.List;

public class OrderedProductDao {
	
	    private final SessionFactory sessionFactory;

	    public OrderedProductDao(SessionFactory sessionFactory) {
	        this.sessionFactory = sessionFactory;
	    }

	    public void insertOrderedProduct(OrderedProduct ordProduct) {
	        Transaction transaction = null;
	        try (Session session = sessionFactory.openSession()) {
	            transaction = session.beginTransaction();
	            session.save(ordProduct);
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }
	    }

	    public List<OrderedProduct> getAllOrderedProduct(int orderId) {
	        try (Session session = sessionFactory.openSession()) {
	            return session.createQuery("FROM OrderedProduct WHERE orderId = :orderId", OrderedProduct.class)
	                    .setParameter("orderId", orderId)
	                    .list();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return new ArrayList<>();
	    }
}
