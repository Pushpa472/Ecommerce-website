package com.learn.mycart.servlets;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.learn.mycart.dao.CartDao;
import com.learn.mycart.dao.OrderDao;
import com.learn.mycart.dao.OrderedProductDao;
import com.learn.mycart.dao.ProductDao;
import com.learn.mycart.entities.Order;
import com.learn.mycart.entities.Payment;
import com.learn.mycart.entities.OrderedProduct;
import com.learn.mycart.entities.Product;
import com.learn.mycart.entities.User;
import com.learn.mycart.helper.FactoryProvider;
import com.learn.mycart.helper.OrderIdGenerator;


@WebServlet("/OrderOperationServlet")
public class OrderOperationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	try {
        	// Retrieve form parameters
            String cardNo = request.getParameter("cardno");
     	    String cvv = request.getParameter("cvv");
     	    String expiryDate = request.getParameter("expiryDate");
     	    String cardHolderName = request.getParameter("cardHolderName");

             // Create a Contact object
                Payment pay = new Payment();
     	        pay.setCardNumber(cardNo);
     	        pay.setCvv(cvv);
     	        pay.setExpiryDate(expiryDate);
     	        pay.setCardHolderName(cardHolderName);
            
             Session hibernateSession = FactoryProvider.getFactory().openSession();
             // Save the Contact object to the database
             org.hibernate.Transaction tx = hibernateSession.beginTransaction();
             hibernateSession.save(pay);
             tx.commit();

             // Close the Hibernate session
             hibernateSession.close();
             // Forward or redirect to a success page
             HttpSession httpSession = request.getSession();
             httpSession.setAttribute("message", "Order Placed successfully!!");
             response.sendRedirect("success.jsp"); 
    	}catch (Exception e) {
            e.printStackTrace(); 
        }
    }
    	
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}

