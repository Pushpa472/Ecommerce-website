package com.learn.mycart.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import java.sql.Timestamp;

@Entity
@Table(name = "Orders") // Rename the table to avoid conflict with reserved keyword
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String orderId;
    private String productId;
    private String pName;
    private String pPhoto;
    private String CategoryTitle;
    private String status;
    private String pQuantity;
    private int pPrice;
    private Timestamp date;
    private String paymentType;
    private String TransactionId;
    private String DeliveryDate;
    private int userId;
    
	public Order(int id, String orderId, String productId, String pName, String pPhoto, String categoryTitle,
			String status, String pQuantity, int pPrice, Timestamp date, String paymentType, String transactionId,
			String deliveryDate, int userId) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.productId = productId;
		this.pName = pName;
		this.pPhoto = pPhoto;
		CategoryTitle = categoryTitle;
		this.status = status;
		this.pQuantity = pQuantity;
		this.pPrice = pPrice;
		this.date = date;
		this.paymentType = paymentType;
		TransactionId = transactionId;
		DeliveryDate = deliveryDate;
		this.userId = userId;
	}
	
	public Order() {
		super();
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getpPhoto() {
		return pPhoto;
	}
	public void setpPhoto(String pPhoto) {
		this.pPhoto = pPhoto;
	}
	public String getCategoryTitle() {
		return CategoryTitle;
	}
	public void setCategoryTitle(String categoryTitle) {
		CategoryTitle = categoryTitle;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getpQuantity() {
		return pQuantity;
	}
	public void setpQuantity(String pQuantity) {
		this.pQuantity = pQuantity;
	}
	public int getpPrice() {
		return pPrice;
	}
	public void setpPrice(int pPrice) {
		this.pPrice = pPrice;
	}
	public Timestamp getDate() {
		return date;
	}
	public void setDate(Timestamp date) {
		this.date = date;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getTransactionId() {
		return TransactionId;
	}
	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}
	public String getDeliveryDate() {
		return DeliveryDate;
	}
	public void setDeliveryDate(String deliveryDate) {
		DeliveryDate = deliveryDate;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	@Override
	public String toString() {
		return "Order [id=" + id + ", orderId=" + orderId + ", productId=" + productId + ", pName=" + pName
				+ ", pPhoto=" + pPhoto + ", CategoryTitle=" + CategoryTitle + ", status=" + status + ", pQuantity="
				+ pQuantity + ", pPrice=" + pPrice + ", date=" + date + ", paymentType=" + paymentType
				+ ", TransactionId=" + TransactionId + ", DeliveryDate=" + DeliveryDate + ", userId=" + userId + "]";
	}
    
}
