package com.learn.mycart.entities;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class OrderedProduct {
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int id;
	    private String pName;
	    private int pQuantity;
	    private String categoryTitle;
	    private int pPrice;
	    private String pPhoto;
	    private int orderId;
	    
		public OrderedProduct(int id, String pName, int pQuantity, String categoryTitle, int pPrice, String pPhoto,
				int orderId) {
			super();
			this.id = id;
			this.pName = pName;
			this.pQuantity = pQuantity;
			this.categoryTitle = categoryTitle;
			this.pPrice = pPrice;
			this.pPhoto = pPhoto;
			this.orderId = orderId;
		}

		public OrderedProduct() {
			super();
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getpName() {
			return pName;
		}

		public void setpName(String pName) {
			this.pName = pName;
		}

		public int getpQuantity() {
			return pQuantity;
		}

		public void setpQuantity(int pQuantity) {
			this.pQuantity = pQuantity;
		}

		public String getCategoryTitle() {
			return categoryTitle;
		}

		public void setCategoryTitle(String categoryTitle) {
			this.categoryTitle = categoryTitle;
		}

		public int getpPrice() {
			return pPrice;
		}

		public void setpPrice(int pPrice) {
			this.pPrice = pPrice;
		}

		public String getpPhoto() {
			return pPhoto;
		}

		public void setpPhoto(String pPhoto) {
			this.pPhoto = pPhoto;
		}

		public int getOrderId() {
			return orderId;
		}

		public void setOrderId(int orderId) {
			this.orderId = orderId;
		}

		@Override
		public String toString() {
			return "OrderedProduct [id=" + id + ", pName=" + pName + ", pQuantity=" + pQuantity + ", categoryTitle="
					+ categoryTitle + ", pPrice=" + pPrice + ", pPhoto=" + pPhoto + ", orderId=" + orderId + "]";
		}
}
