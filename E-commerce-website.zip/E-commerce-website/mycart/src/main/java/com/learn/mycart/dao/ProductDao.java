package com.learn.mycart.dao;

import com.learn.mycart.entities.Product;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import javax.persistence.EntityManager;

public class ProductDao {

    private SessionFactory factory;
	private EntityManager session;
	private SessionFactory sessionFactory;

    public ProductDao(SessionFactory factory) {
        this.factory = factory;
    }

    public boolean saveProduct(Product product) {
        boolean f = false;
        try {

            Session session = this.factory.openSession();
            Transaction tx = session.beginTransaction();

            session.save(product);

            tx.commit();// Commit the transaction if all operations succeed
            session.close();// Close the session after completing the transaction
            f = true;

        } catch (Exception e) {
            e.printStackTrace();
            f = false;
        }

        return f;
    }
    //get all products
    public List<Product> getAllProducts() {
        Session s = this.factory.openSession();
        Query query = s.createQuery("from Product");
        List<Product> list = query.list();
        return list;
    }

    //get all  products of given category
    public List<Product> getAllProductsById(int cid) {
        Session s = this.factory.openSession();
        Query query = s.createQuery("from Product as p where p.category.categoryId =: id");
        query.setParameter("id", cid);
        List<Product> list = query.list();
        return list;
    }
   
    //
    public Product getProductsByProductId(int pId) {
        Product product = null;
        try (Session session = this.factory.openSession()) {
            Transaction tx = session.beginTransaction();

            // Retrieve the product using Hibernate
            product = session.get(Product.class, pId);

            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return product;
    }

 // Update a product
    public boolean updateProduct(Product product) {
        boolean success = false;
        try (Session session = this.factory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.update(product);
            tx.commit();
            success = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }

    // Delete a product
    public void deleteProduct(int pid) {
        try (Session session = this.factory.openSession()) {
            Transaction tx = session.beginTransaction();
            // Retrieve the product using Hibernate
            Product product = session.get(Product.class, pid);
            if (product != null) {
                // Delete the product
                session.delete(product);
                // Commit the transaction
                tx.commit();
            } 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //search product
    public List<Product> searchProducts(String query) {
        List<Product> searchResults = null;
        try (
        	Session session = factory.openSession()) {
            // Use HQL to perform a case-insensitive search on product name and description
            String hql = "FROM Product WHERE LOWER(pName) LIKE :query OR LOWER(pDesc) LIKE :query";
            Query<Product> queryObject = session.createQuery(hql, Product.class);
            queryObject.setParameter("query", "%" + query.toLowerCase() + "%");
            searchResults = queryObject.getResultList();
        } catch (Exception e) {
            e.printStackTrace(); // Handle the exception appropriately in a production environment
        }
        return searchResults;
    }

	
    
}
   

