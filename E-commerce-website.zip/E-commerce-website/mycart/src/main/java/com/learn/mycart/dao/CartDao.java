package com.learn.mycart.dao;


import com.learn.mycart.entities.Product;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;


import java.util.ArrayList;
import java.util.List;

import java.util.stream.Collectors;

import javax.transaction.Transaction;

public class CartDao {

	private SessionFactory sessionFactory;

	 public CartDao(SessionFactory sessionFactory) {
	        this.sessionFactory = sessionFactory;
	    }
    public CartDao() {
		// TODO Auto-generated constructor stub
	}
	// Data class for Cart
    static class Cart {
        private List<Product> products = new ArrayList<>();

        private void addProduct(int productId, String productName, int productPrice, int productQuantity, String productPhoto) {
            Product product = new Product();
            product.setpId(productId);
            product.setpName(productName);
            product.setpPrice(productPrice);
            product.setpQuantity(productQuantity);
            product.setpPhoto(productPhoto);
            ((List<Product>) product).add(product);
        }

        private void updateProductQuantity(int productId, int newQuantity) {
            for (Product product : products) {
                if (product.getpId() == productId) {
                    product.setpQuantity(newQuantity);
                    break;
                }
            }
        }

        private void removeProduct(int productId) {
            products = products.stream()
                    .filter(product -> product.getpId() != productId)
                    .collect(Collectors.toList());
        }

        private int getTotalItems() {
            return products.size();
        }

        private double getTotalPrice() {
            return products.stream()
                    .mapToDouble(product -> product.getpPrice() * product.getpQuantity())
                    .sum();
        }

		private void addProduct1(int productId, String productName, int productPrice, int productQuantity,
				String productPhoto) {
			// TODO Auto-generated method stub
			
		}
    }

    private Cart cart = new Cart();

    public void addToCart(int productId, String productName, int productPrice, int productQuantity, String productPhoto) {
        cart.addProduct(productId, productName, productPrice, productQuantity, productPhoto);
        updateCart();
    }

    private void updateCart() {
        // Display the cart
        System.out.println("Cart Items:");
        for (Product product : cart.products) {
            System.out.println("Product ID: " + product.getpId());
            System.out.println("Product Name: " + product.getpName());
            System.out.println("Product Price: " + product.getpPrice());
            System.out.println("Product Quantity: " + product.getpQuantity());
            System.out.println("Product Photo: " + product.getpPhoto());
        }
        System.out.println("Total Items: " + cart.getTotalItems());
        System.out.println("Total Price: " + cart.getTotalPrice());
    }

    public void deleteItemFromCart(long productId) {
        cart.removeProduct((int) productId);
        updateCart();
    }

    private static void main(String[] args) {
        CartDao cart = new CartDao();

        // Adding products to cart
        cart.addToCart(1, "Product 1", (int) 100.0, 2, "photo1.jpg");
        cart.addToCart(2, "Product 2", (int) 200.0, 3, "photo2.jpg");

        // Removing a product from cart
        cart.deleteItemFromCart(2);
    }

    public List<Product> getCartListByUserId(int userId) {
        List<Product> list = new ArrayList<>();
        try (Session session = sessionFactory.openSession()) {
            String hql = "select p from Cart c join c.products p where c.userId = :uid";
            Query<Product> query = session.createQuery(hql, Product.class);
            query.setParameter("uid", userId);
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    public void removeAllProduct() {
        try (Session session = sessionFactory.openSession()) {
            org.hibernate.Transaction tx = session.beginTransaction();
            String hql = "delete from Cart";
            Query query = session.createQuery(hql);
            query.executeUpdate();
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
