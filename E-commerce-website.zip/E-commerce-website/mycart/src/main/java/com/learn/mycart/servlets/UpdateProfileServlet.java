package com.learn.mycart.servlets;

import com.learn.mycart.entities.User;
import java.io.IOException;
import com.learn.mycart.helper.FactoryProvider;
import com.learn.mycart.dao.UserDao;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

//@WebServlet("/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {
	private ServletRequest httpSession;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
	        throws ServletException, IOException {
	        try {
	        	 HttpSession httpSession = request.getSession();
		         User user = (User) httpSession.getAttribute("current-user");

		            // Retrieve form data
		            String userName = request.getParameter("user_name");
		            String userEmail = request.getParameter("user_email");
		            String userPassword = request.getParameter("user_password");
		            String userContact = request.getParameter("user_phone");
		            String userAddress = request.getParameter("user_address");

		            // Update the user object
		            user.setUserName(userName);
		            user.setUserEmail(userEmail);
		            user.setUserPassword(userPassword);
		            user.setUserContact(userContact);
		            user.setUserAddress(userAddress);

		            // Hibernate configuration and session setup
		        //    UserDao dao = new UserDao(FactoryProvider.getFactory());
		            Session hibernateSession = FactoryProvider.getFactory().openSession();
	                Transaction tx = hibernateSession.beginTransaction();                
	                hibernateSession.update(user);              
	                tx.commit();
	                hibernateSession.close();                
	                HttpSession httpSession1 = request.getSession();
		            httpSession1.setAttribute("message", "Profile Update Successful");
		            response.sendRedirect("profile.jsp");
		            
		         } catch (Exception e) {
		                   
		        	 httpSession.setAttribute("message", "something went wrong! please try again...");
		                  response.sendRedirect("profile.jsp");
		             }
		         }
		        
		    }
   


	    
	