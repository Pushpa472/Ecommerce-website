package com.learn.mycart.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.learn.mycart.dao.OrderDao;
import com.learn.mycart.helper.FactoryProvider;

@WebServlet("/UpdateOrderServlet")
public class UpdateOrderServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String status = request.getParameter("status");
        OrderDao orderDao = new OrderDao(FactoryProvider.getFactory());
        orderDao.updateOrderStatus(id, status);
        
        if (status.equals("Delivered")) {
        	 HttpSession httpSession = request.getSession();
             httpSession.setAttribute("message", "Order successfully delivered!");                
             response.sendRedirect("displayorder.jsp");
          
        } else if (status.equals("Out For Delivery")) {
        	HttpSession httpSession = request.getSession();
            httpSession.setAttribute("message", "Order is out for delivery!");                
            response.sendRedirect("displayorder.jsp");
        }
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}

