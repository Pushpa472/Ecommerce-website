package com.learn.mycart.entities;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class Admin {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int adminId;
	private int password;
	private int contact;
	private String adminName;
	private String email;
	private String address;
	
	public Admin(int adminId, int password, int contact, String adminName, String email, String address) {
		super();
		this.adminId = adminId;
		this.password = password;
		this.contact = contact;
		this.adminName = adminName;
		this.email = email;
		this.address = address;
	}

	public Admin() {
		super();
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public int getPassword() {
		return password;
	}

	public void setPassword(int password) {
		this.password = password;
	}

	public int getContact() {
		return contact;
	}

	public void setContact(int contact) {
		this.contact = contact;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", password=" + password + ", contact=" + contact + ", adminName="
				+ adminName + ", email=" + email + ", address=" + address + "]";
	}

	
}
