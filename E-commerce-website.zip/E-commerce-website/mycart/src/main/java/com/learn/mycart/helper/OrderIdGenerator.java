package com.learn.mycart.helper;

import java.text.SimpleDateFormat;
import java.util.Date;

public class OrderIdGenerator {
	 public static String getOrderId() {
	        String orderId = "";

	        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
	        orderId = sdf.format(new Date());
	        orderId = "ORD-" + orderId;

	        return orderId;
	    }

	    public static void main(String[] args) {
	        // Example usage:
	        String orderId = getOrderId();
	        System.out.println("Generated Order ID: " + orderId);
	    }
	    

		public static String generateTransId() {
			String tId = null;

			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
			tId = sdf.format(new Date());
			tId = "T" + tId;

			return tId;
		}
}