package com.learn.mycart.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.learn.mycart.entities.Contact_Us;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.learn.mycart.helper.FactoryProvider;

public class ContactServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
		try {
            // Retrieve form parameters
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String message = request.getParameter("message");
            String subject = request.getParameter("subject");

            // Create Hibernate session
            
            Session hibernateSession = FactoryProvider.getFactory().openSession();
            // Create a Contact object
            Contact_Us contact = new Contact_Us();
            contact.setUserName(name);
            contact.setUserEmail(email);
            contact.setMessage(message);
            contact.setSubject(subject);
           
            // Save the Contact object to the database
            Transaction transaction = hibernateSession.beginTransaction();
            hibernateSession.save(contact);
            transaction.commit();

            // Close the Hibernate session
            hibernateSession.close();

            // Forward or redirect to a success page
            HttpSession httpSession = request.getSession();
            httpSession.setAttribute("message", "Message sent successfully!!");
            response.sendRedirect("contact_us.jsp");

        } catch (Exception e) {
            e.printStackTrace();
           
        }
	}

}


