package com.learn.mycart.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Contact_Us {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Id;
    private String UserName;
    private String UserEmail;
    private String Message;
    private String subject;
    
	public Contact_Us(int Id, String userName, String userEmail, String message, String subject) {
		super();
		this.Id = Id;
		UserName = userName;
		UserEmail = userEmail;
		Message = message;
		this.subject = subject;
	}

	public Contact_Us() {
		super();
	}

	public int getUserId() {
		return Id;
	}

	public void setUserId(int userId) {
		this.Id = userId;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getUserEmail() {
		return UserEmail;
	}

	public void setUserEmail(String userEmail) {
		UserEmail = userEmail;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	@Override
	public String toString() {
		return "Contact_Us [userId=" + Id + ", UserName=" + UserName + ", UserEmail=" + UserEmail + ", Message="
				+ Message + ", subject=" + subject + "]";
	}
    
	
}
